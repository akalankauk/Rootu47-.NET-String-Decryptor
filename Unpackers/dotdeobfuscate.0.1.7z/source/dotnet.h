/* This file is part of .deobfuscate (also known as dotdeobfuscate).

   Copyright 2007, someone with a name that hashes to
   382d54883bde4178ba136eba1719fa57816cd971 using RIPEMD-160.

   .deobfuscate is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   .deobfuscate is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */


#include "defines.h"

U32 findstream(const char *name, struct dotnet_fileinfo *info, FILE* file);
U32 getstream(const char *name, struct dotnet_fileinfo *info, FILE* file);
U32 getrows(uint idx, struct dotnet_fileinfo *info, FILE* file);
void getmethodname(char* buffer, U32 declaration, struct dotnet_fileinfo *info, FILE* file);
U32 virtual2raw(FILE* file, U32 virt, struct dotnet_fileinfo *info);

void get_info(struct dotnet_fileinfo *info, FILE* file);
void for_all_methods(int (*callback)(U32 offset, U32 declaration, void *userparam, struct dotnet_fileinfo *info, FILE* file), void* userparam, struct dotnet_fileinfo *info, FILE* file);
unsigned int il_lde(const U8 *opcodes) __attribute__((pure));

void* gettarget(const U8* here, uint targetnum) __attribute__((pure));
int continues(const U8 *opcodes)  __attribute__((pure));
enum branchtypes getbranchtype(const U8 *here) __attribute__((pure));
uint makebranch(enum branchtypes type, S32 *deltas, uint numdeltas, U8 *buffer, uint bufsize);
void* getbranchtypename(enum branchtypes type, char *buffer);
void* getdirecttarget(const U8* here, uint targetnum);
uint decodeinteger(U8 **data_ptr);
void encodeinteger(U8 **data_ptr, U32 integer);
