/* This file is part of .deobfuscate (also known as dotdeobfuscate).

   Copyright 2007, someone with a name that hashes to
   382d54883bde4178ba136eba1719fa57816cd971 using RIPEMD-160.

   .deobfuscate is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   .deobfuscate is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */


/** \file
 *  Some global definitions.
 */

#ifndef DEFINES_H
#define DEFINES_H

#include <stdint.h>
#include "gcc.h"

/** Branch types, f.i. "branch if equal" */
enum branchtypes {
BR_NOTBRANCH,
/* Needs to be order of opcodes */
    BR_UNCONDITIONAL,
    BR_FALSE, BR_TRUE,
    BR_EQUAL, BR_GREATER_EQUAL, BR_GREATER, BR_LESS_EQUAL, BR_LESS,
    BR_UN_NEQUAL, BR_UN_GREATER_EQUAL, BR_UN_GREATER, BR_UN_LESS_EQUAL, BR_UN_LESS,
/* No longer */
BR_SWITCH, BR_LEAVE
};

/** Type of debugging info that dbgprint can output */
enum debugtypes {
/** Memory debugging */
MEM_DEBUG,
/** Tree debugging */
CFG_DEBUG,
/** Function (method) debugging */
FUNC_DEBUG,
/** String decryption debugging */
STRING_DEBUG
};

/* Please make sure these are little endian! */

typedef uint64_t U64;
typedef uint32_t U32;
typedef uint16_t U16;
typedef uint8_t   U8;

typedef int64_t  S64;
typedef int32_t  S32;
typedef int16_t  S16;
typedef int8_t    S8;

typedef unsigned int uint;
typedef unsigned char uchar;

/** File information struct */
struct dotnet_fileinfo {
    /** A bitmask-QWORD that tells us which MetaData Tables are present in the assembly. */
    U64 maskvalid;
    /** Offset of the PE header in the file */
    U32 pe_header;
    /** Offset of the .NET Directory (old COM directory) in the file */
    U32 dotnet_header;
    /** Offset of the MetaData header in the file */
    U32 meta_header;
    /** Offset of the section table in the file */
    U32 sections;
    /** Offset of the stream headers in the file */
    U32 streamheaders;
    /** Offset of the MetaData tables in the file */
    U32 metatables;
    /** The number of sections in this file */
    U16 numsections;
    /** The number of MetaData streams in this file */
    U16 numberofstreams;
    /** A byte that tells us the size that indexes in to the "#String", "#GUID" and "#Blob" streams will have */
    U8  heapsizes;

    /** Size of an index into the "#String" stream */
    uint stridx;
    /** Size of an index into the "#GUID" stream */
    uint guididx;
    /** Size of an index into the "#Blob" stream */
    uint blobidx;
    /** Size of a TypeDefOrRef index */
    uint typedeforref;
    /** Size of a ResolutionScope index */
    uint resolutionscope;

    /* Feel free to extend this to your needs */
};

#endif /* DEFINES_H */
