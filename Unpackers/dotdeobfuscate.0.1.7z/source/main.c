/* This file is part of .deobfuscate (also known as dotdeobfuscate).

   Copyright 2007, someone with a name that hashes to
   382d54883bde4178ba136eba1719fa57816cd971 using RIPEMD-160.

   .deobfuscate is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   .deobfuscate is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */


/** \mainpage
 *  Welcome to the source documentation of .deobfuscate!
 *
 *  The source was intended to be readable and reusable.
 *  If you have any question, bugfix or addition, please contact me on sourceforge
 *
 *  Overview: main() calls get_info(), and then for_all_methods().
 *  That calls deobfuscate() for every method. In that function it calls makecfg() and rebuildcfg().
 *
 *  This program is free software: you can redistribute it and/or modify it
 *  under the terms of the GNU General Public License
 *  as published by the Free Software Foundation, either version 3 of the License,
 *  or (at your option) any later version.
 *
 *  Keep in mind that the main program uses <a href="http://gopt.sourceforge.net/">Gopt</a>. Please read it's license too.
 */


/** \file
 *  The main file.
 *  It includes main() and some functions that are specific to .deobfuscate
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define GOPT_PASSMALLOC
#include "gopt-9/gopt.h"

#include "defines.h"
#include "dotnet.h"
#include "includes.h"
#include "cfg.h"
#include "protector.h"

/** Copy a file */
void copy(FILE *dest, FILE *src)
{
    char buffer[512];
    size_t temp;

    fseek(src, 0, SEEK_SET);
    fseek(dest, 0, SEEK_SET);
    do
    {
        temp = fread(buffer, sizeof(char), 512, src);
        fwrite(buffer, sizeof(char), temp, dest) == temp || die(1, "Could not copy file!");
    } while (temp != 0);
}

/** Remove obfuscations by calling all deobfuscation functions in the list */
void removeobfuscations(U8* here, void *userparam)
{
    uint i;
    void **userparam2;
    void (**func_ptr)(U8*, void *);


    userparam2 = userparam;
    func_ptr = userparam2[1];

    for(i = 0; func_ptr[i] != NULL; i++)
        func_ptr[i](here, userparam);
}

/** This is done for all methods. It is mainly a wrapper for the cfg functions */
int deobfuscate(U32 address, U32 declaration, void *userparam, struct dotnet_fileinfo *info, FILE* infile)
{
    FILE* outfile;
    char name[256];
    U8 header[12];
    U8 *methodbody, *rebuilded;
    U32 bodystart, methodsize;
    unsigned int headerisfat, rebuildedsize;
    struct cfgstruct cfg;
    void **userparam2;
    int passes, i;

    userparam2 = userparam;

    outfile = *(FILE **)userparam2[0];
    passes = *(int *)userparam2[4];

    /* Show method info */
    getmethodname(name, declaration, info, infile);
    dbgprint(FUNC_DEBUG, "\nMethod: %s\nAddress = %x\nDeclaration = %x\n", name, address, declaration);

    if(address == 0) /* Method does not provide an implementation? */
        return 1;

    /* Read the header of the method */
    if(fseek(infile, address, SEEK_SET) != 0)
    {
        fprintf(stderr, "Can't move to header!\n");
        return 1;
    }

    if(fread(header, sizeof(char), 12, infile) != 12)
    {
        fprintf(stderr, "Can't read header!\n");
        return 1;
    }

    assert((header[0] & 3) == 2 || (header[0] & 3) == 3); /* Header must be tiny or fat! */

    if((header[0] & 3) == 2)            /* Tiny header? */
    {
        methodsize = header[0] >> 2;
        bodystart = address + 1;
        headerisfat = 0;
    }
    else                                /* Fat header */
    {
        methodsize = *(U32 *)(header + 4);
        bodystart = address + (*(U16 *)header >> 12) * 4;
        headerisfat = 1;
    }

    dbgprint(FUNC_DEBUG, "Length = %x\n", methodsize);

    /* Read the body of the method */
    methodbody = xmalloc(methodsize);

    if(fseek(infile, bodystart, SEEK_SET) != 0)
    {
        fprintf(stderr, "Can't move to method!\n");
        return 1;
    }

    if(fread(methodbody, sizeof(U8), methodsize, infile) != methodsize)
    {
        fprintf(stderr, "Can't read method!\n");
        return 1;
    }
    i = 0;
    do
    {
        /* Make a cfg */
        cfg.numvertices = 0;
        cfg.vertices = NULL;
        cfg.start = methodbody;
        cfg.size = methodsize;
        makecfg(methodbody, &cfg, &removeobfuscations, userparam);

        /* Rebuild the cfg */
        rebuilded = xcalloc(methodsize);
        rebuildedsize = rebuildcfg(rebuilded, methodsize, &cfg);

        if(rebuildedsize == -1)
        {
            dbgprint(FUNC_DEBUG, "Failed :(\n");
            xfree(rebuilded);
            freecfg(&cfg);
            xfree(methodbody);
            return 1;
        }

        memcpy(methodbody, rebuilded, methodsize);
        xfree(rebuilded);

        freecfg(&cfg);

        i++;
    } while(i < passes);

    /* Write it back */
    if(fseek(outfile, bodystart, SEEK_SET) != 0)
    {
        fprintf(stderr, "Can't move to method!\n");
        return 1;
    }
    if(fwrite(methodbody, sizeof(U8), methodsize, outfile) != methodsize)
    {
        fprintf(stderr, "Can't write method!\n");
        return 1;
    }

    xfree(methodbody);

    /* fix method size in header */
    if(headerisfat)
    {
        *(U32 *)(header + 4) = rebuildedsize;
        header[0] &= ~0x8; /* FIXME: turn off CorILMethod_MoreSects until I really handle exception blocks */
    }
    else
        header[0] = rebuildedsize << 2 | (header[0] & 0x3);

    if(fseek(outfile, address, SEEK_SET) != 0)
    {
        fprintf(stderr, "Can't move to header!\n");
        return 1;
    }
    if(fwrite(header, sizeof(U8), headerisfat ? 12 : 1, outfile) != (headerisfat ? 12 : 1))
    {
        fprintf(stderr, "Can't write header\n");
        return 1;
    }

    return 1;
}

const char *howtouse ="\
Usage: %s in [out] [options]\n\
\n\
Parameters:\n\
\tin                      File to use as input\n\
\tout                     File to use as output.\n\
\t                        Optional, default is prepending fixed_ to in\n\
Options:\n\
\t-d type, --debug=type   Toggle debug output for type, which can be cfg,\n\
\t                        memory or string\n\
\t-h, --help              Get this help\n\
\t-p num, --passes=num    Perform num passes over every method\n\
\t-q, --quiet             Don't output methods processed\n\
\t-v, --version           Show version and copyright information\n\
\t-C, --copyright         Show copyright information\
";

const char *version= ".deobfuscate 0.1, compiled " __DATE__;

const char *license= "\
Copyright 2007, someone with a name that hashes to\n\
382d54883bde4178ba136eba1719fa57816cd971 using RIPEMD-160.\n\
\n\
.deobfuscate is free software; you can redistribute it and/or modify\n\
it under the terms of the GNU General Public License as published by\n\
the Free Software Foundation; either version 3 of the License, or\n\
(at your option) any later version.\n\
\n\
.deobfuscate is distributed in the hope that it will be useful,\n\
but WITHOUT ANY WARRANTY; without even the implied warranty of\n\
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n\
GNU General Public License for more details.\n\
\n\
You should have received a copy of the GNU General Public License\n\
along with this program.  If not, see <http://www.gnu.org/licenses/>.\n\
\n\
This program uses Gopt ( http://gopt.sourceforge.net/ ).\n\
Tom Vajzovic, the author of that software and its documentation,\n\
has permanently disclaimed all copyright and other intellectual property\n\
rights in them, including the right to be identified as the author.\
";

int main(int argc, char* argv[])
{
    char *infile, *outfile;
    FILE *in, *out;
    struct dotnet_fileinfo info;
    char **debug_types, *passes_a;
    uint numtypes, numtypes2, i, lastslash;
    int passes = 1;

    /** Null terminated list of functions that will be called for every opcode in the file */
    void (*deobfuscation_funcs[])(U8* here, void *userparam) = {removeobfuscation, NULL};
    void* userparam[] = {&out, &deobfuscation_funcs, 0, &info, &passes};

    /* Get options, see Gopt documentation */
    void *options= gopt_start(
        gopt_option('h', 0, gopt_shorts('h', '?'), gopt_longs("help")),
        gopt_option('v', 0, gopt_shorts('v'), gopt_longs("version")),
        gopt_option('C', 0, gopt_shorts('C'), gopt_longs("copyright")),
        gopt_option('q', 0, gopt_shorts('q'), gopt_longs("quiet")),
        gopt_option('d', GOPT_REPEAT | GOPT_ARG, gopt_shorts('d'), gopt_longs("debug")),
        gopt_option('p', GOPT_ARG, gopt_shorts('p'), gopt_longs("passes"))
    );

    options = gopt_sort(options, &argc, (const char **)argv, stderr, exit, EXIT_FAILURE);

    toggledebug(FUNC_DEBUG); /* default to ON */

    if(gopt(options, 'h'))
        die(0, howtouse, argv[0]);
    if(gopt_arg(options, 'p', (const char **) &passes_a))
    {
        passes = atoi(passes_a);
        if(passes < 1)
            die(1, "Invalid number of passes");
    }

    if(gopt(options, 'v'))
        die(0, version);
    if(gopt(options, 'C'))
        die(0, license);
    if(gopt(options, 'q'))
        toggledebug(FUNC_DEBUG);

    numtypes = gopt(options, 'd');
    debug_types = malloc((numtypes+1) * sizeof(char *));
    gopt_args(options, 'd', numtypes, &numtypes2, (const char **)debug_types);
    for(i = 0; debug_types[i] != NULL; i++)
    {
        if(strcmp(debug_types[i], "cfg") == 0)
            toggledebug(CFG_DEBUG);
        else if(strcmp(debug_types[i], "memory") == 0)
            toggledebug(MEM_DEBUG);
        else if(strcmp(debug_types[i], "string") == 0)
            toggledebug(STRING_DEBUG);
        else
            die(1, "Unrecognized debug type \"%s\"", debug_types[i]);
    }

    if(argc <= 1)   /* We need an input file, noob! */
        die(0, howtouse, argv[0]);

    infile = argv[1];

    if(argc == 2)   /* Either output to argv[2] or "fixed_" + argv[1] */
    {
        outfile = xmalloc(strlen("fixed_")+strlen(infile)+1);
        /* Handle directories in front of the base name */
        lastslash = 0;
        for(i = 0; i < strlen(infile); i++)
            if(infile[i] == '/' || infile[i] == '\\')
                lastslash = i + 1;
        strcpy(outfile, infile);
        strcpy(outfile+lastslash, "fixed_");
        strcat(outfile, infile+lastslash);
    }
    else
        outfile = argv[2];

    (in = fopen(infile, "rb")) || die(1, "Can't open input file!");
    get_info(&info, in);

    (out = fopen(outfile, "w+b")) || die(1, "Can't open output file!");

    dbgprint(FUNC_DEBUG, "Copying file...\n");
    copy(out, in);

    for_all_methods(&deobfuscate, userparam, &info, in);

    if(argc == 2)
        free(outfile);

    return 0;
}
