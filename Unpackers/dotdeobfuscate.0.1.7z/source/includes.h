/* This file is part of .deobfuscate (also known as dotdeobfuscate).

   Copyright 2007, someone with a name that hashes to
   382d54883bde4178ba136eba1719fa57816cd971 using RIPEMD-160.

   .deobfuscate is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   .deobfuscate is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */


#include "gcc.h"

int die(unsigned char errorcode, const char* message, ...) __attribute__((noreturn)) __attribute__ ((format (printf, 2, 3)));
void* xmalloc(size_t size) __attribute__((malloc));
void* xrealloc(void *ptr, size_t size) __attribute__((malloc));
void* xcalloc(size_t size) __attribute__((malloc));
void xfree(void *ptr);
void dbgprint(uint type, const char* message, ...);
uint toggledebug(uint type);
uint isdebug(uint type);
