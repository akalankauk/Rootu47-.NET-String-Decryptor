#include "defines.h"

struct vertexstruct
{
    void *start;
    void *end;
    void *realend;
    uint numexits;
    enum branchtypes exittype;
    uint *exits;
};

struct cfgstruct
{
    void *start;
    uint size;
    uint numvertices;
    struct vertexstruct *vertices;
};

void makecfg(U8 *here, struct cfgstruct *cfg, void (*removeobfuscation)(U8*, void*), void* userparam);
uint rebuildcfg(U8* outbuffer, uint outlength, struct cfgstruct *cfg);
void freecfg(struct cfgstruct *cfg);
