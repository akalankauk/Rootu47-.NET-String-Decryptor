/* This file is part of .deobfuscate (also known as dotdeobfuscate).

   Copyright 2007, someone with a name that hashes to
   382d54883bde4178ba136eba1719fa57816cd971 using RIPEMD-160.

   .deobfuscate is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   .deobfuscate is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */


/** \file
 *  This is the file that handles all .NET specifics.
 *  It contains functions regarding MetaData and PE files,
 *  but also functions related to Intermediate Language.
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"
#include "includes.h"

/** Computes raw offset from virtual offset in a PE file */
U32 virtual2raw(FILE* file, U32 virt, struct dotnet_fileinfo *info)
{
    void *ptr;
    uint i;
    U32 virtaddress, virtsize, physaddress;

    ptr = xmalloc(info->numsections * 0x28);

    fseek(file, info->sections, SEEK_SET) && die(1, "Can't move to sections table");
    fread(ptr, 0x28, info->numsections, file) == info->numsections || die(1, "Can't read sections table");

    for(i = 0; i < info->numsections; i++)
    {
        virtaddress = *(U32 *)(ptr + i*0x28 + 0xC);
        if(virt >= virtaddress)
        {
            virtsize = *(U32 *)(ptr + i*0x28 + 0x8);
            if(virt < virtaddress + virtsize)
            {
                physaddress = *(U32 *)(ptr + i*0x28 + 0x14);
                xfree(ptr);
                return virt - virtaddress + physaddress;
            }
        }
    }

    xfree(ptr);
    return 0;
}

/** Get the header offset of a stream with the supplied name (or 0 if it can't be found) */
U32 findstream(const char *name, struct dotnet_fileinfo *info, FILE* file)
{
    char stringbuffer[512]; /* 512 bytes ought to be enough for everyone */
    U32 streamptr = info->streamheaders;
    uint counter;

    for(counter = 0; counter < info->numberofstreams; counter++)
    {
        fseek(file, streamptr + 8, SEEK_SET) && die(1, "Can't move to stream header"); /* +8 is name offset */
        fread(stringbuffer, sizeof(char), 512, file);
        stringbuffer[511] = 0;  /* _always_ terminate strings! */

        if(strcmp(name, stringbuffer) == 0)
            return streamptr;   /* found */

        streamptr += 8 + ((strlen(stringbuffer) + 1 + 3) & ~3); /* next stream header, aligned by 4 */
    }

    return 0;
}

/** Get the body offset of a stream with the supplied name (or die if it can't be found) */
U32 getstream(const char *name, struct dotnet_fileinfo *info, FILE* file)
{
    U32 temp;
    U32 offset;

    offset = findstream(name, info, file);
    if(offset == 0)
        die(1, "Can't find stream %s", name);

    fseek(file, offset, SEEK_SET) && die(1, "Can't move to stream header");
    fread(&temp, sizeof(U32), 1, file) == 1 || die(1, "Can't read stream header");
    return temp + info->meta_header;
}

/** Get the nuwber of rows for a metatable */
U32 getrows(uint idx, struct dotnet_fileinfo *info, FILE* file)
{
    U32 rows[64];
    int i, j;

    assert(idx < 64);

    if((info->maskvalid & (1ULL << idx)) == 0)  /* If the table is not present, return 0 */
        return 0;

    fseek(file, info->metatables + 0x18, SEEK_SET) && die(1, "Can't move to the row table"); /* 0x18 is the offset of the row table */
    fread(rows, sizeof(U32), 64, file);
    for(i = 0, j = 0; i < idx; i++) /* Move the the right one */
    {
        if((info->maskvalid & (1ULL << i)) == 0)    /* The ones that aren't present don't have an entry */
            continue;                               /* So don't increase j then */
        j++;
    }

    return rows[j];
}

/** Fills the info struct */
void get_info(struct dotnet_fileinfo *info, FILE* file)
{
    /* It's kinda a behemoth, but it's good enough for now */
    U32 rvas, dotnet_offset, meta_offset, length;

    fseek(file, 0x3C, SEEK_SET) && die(1, "Can't move to pe offset");
    fread(&info->pe_header, sizeof(U32), 1, file) == 1 || die(1, "Can't read pe offset");

    fseek(file, info->pe_header+0x6, SEEK_SET) && die(1, "Can't move to pe header");
    fread(&info->numsections, sizeof(U16), 1, file) == 1 || die(1, "Can't read pe header");

    fseek(file, info->pe_header+0x74, SEEK_SET) && die(1, "Can't move to pe header");
    fread(&rvas, sizeof(U32), 1, file) == 1 || die(1, "Can't read pe header");
    info->sections = info->pe_header + rvas*0x8 + 0x78;
    (rvas >= 0x10) || die(1, "Not a .net file");

    fseek(file, info->pe_header+0xE8, SEEK_SET) && die(1, "Can't move to .net offset");
    fread(&dotnet_offset, sizeof(U32), 1, file) == 1 || die(1, "Can't read .net offset");
    info->dotnet_header = virtual2raw(file, dotnet_offset, info);

    if(info->dotnet_header == 0)
        die(1, "Not a .net file");

    fseek(file, info->dotnet_header + 8, SEEK_SET) && die(1, "Can't move to .net header");
    fread(&meta_offset, sizeof(U32), 1, file) == 1 || die(1, "Can't read .net header");

    info->meta_header = virtual2raw(file, meta_offset, info);
    assert(info->meta_header != 0);

    fseek(file, info->meta_header + 0xC, SEEK_SET) && die(1, "Can't move to meta header");
    fread(&length, sizeof(U32), 1, file) == 1 || die(1, "Can't read meta header");

    fseek(file, info->meta_header + 0x10 + length + 2, SEEK_SET) && die(1, "Can't move to meta header");
    fread(&info->numberofstreams, sizeof(U16), 1, file) == 1 || die(1, "Can't read meta header");

    info->streamheaders = info->meta_header + 0x10 + length + 4;
    info->metatables = getstream("#~", info, file);

    fseek(file, info->metatables + 6, SEEK_SET) && die(1, "Can't move to metatables");
    fread(&info->heapsizes, sizeof(U8), 1, file) == 1 || die(1, "Can't read metatables");

    fseek(file, info->metatables + 8, SEEK_SET) && die(1, "Can't move to metatables");
    fread(&info->maskvalid, sizeof(U64), 1, file) == 1 || die(1, "Can't read metatables");

    info->stridx  = info->heapsizes & 1 ? 4 : 2;
    info->guididx = info->heapsizes & 2 ? 4 : 2;
    info->blobidx = info->heapsizes & 4 ? 4 : 2;

    info->typedeforref = (
        getrows( 1, info, file) >= (1 << 14) ||
        getrows( 2, info, file) >= (1 << 14) ||
        getrows(27, info, file) >= (1 << 14)
        )
        ? 4 : 2;

    info->resolutionscope = (
        getrows( 0, info, file) >= (1 << 14) ||
        getrows(26, info, file) >= (1 << 14) ||
        getrows(35, info, file) >= (1 << 14) ||
        getrows( 1, info, file) >= (1 << 14)
        )
        ? 4 : 2;

    /* ... */
}

/** Calls a callback for every method in the file
 *  until there are no more methods or until the callback returns 0
 */
void for_all_methods(int (*callback)(U32 offset, U32 declaration, void *userparam, struct dotnet_fileinfo *info, FILE* file), void* userparam, struct dotnet_fileinfo *info, FILE* file)
{
    U32 ptr, temp, offset;
    int i, methoddefsize, flag;

    ptr = info->metatables + 0x18;

    for(i = 0; i < 64; i++)     /* skip row tables */
    {
        if((info->maskvalid & (1ULL << i)) != 0)
            ptr+=4;
    }

    if((info->maskvalid & (1ULL << 0)) != 0)
    {
        /* skip Module table */
        ptr += 2 + info->stridx + 3*info->guididx;
    }

    if((info->maskvalid & (1ULL << 1)) != 0)
    {
        /* skip TypeRef table */
        ptr += (info->resolutionscope + 2*info->stridx) * getrows(1, info, file);
    }

    if((info->maskvalid & (1ULL << 2)) != 0)
    {
        /* skip TypeDef table */
        ptr +=
        (4 + info->typedeforref + 2*info->stridx +
        (getrows(4, info, file) >= (1 << 16) ? 4 : 2) +
        (getrows(6, info, file) >= (1 << 16) ? 4 : 2)
        ) * getrows(2, info, file);
    }

    assert((info->maskvalid & (1ULL << 3)) == 0);     /* undefined table, shoudn't be there */

    if((info->maskvalid & (1ULL << 4)) != 0)
    {
        /* skip Field table */
        ptr += (2 + info->stridx + info->blobidx) * getrows(4, info, file);
    }

    assert((info->maskvalid & (1ULL << 5)) == 0);     /* undefined table, shoudn't be there */

    if((info->maskvalid & (1ULL << 6)) == 0)
        die(1, "Wtf? No methods?");

    /* At the methoddef table */
    temp = getrows(6, info, file);  /* Help the compiler a bit */
    methoddefsize = 4 + 2 + 2 + info->stridx + info->blobidx + (getrows(8, info, file) >= (1 << 16) ? 4 : 2);
    flag = 1;
    for(i = 0; i < temp && flag != 0; i++)
    {
        fseek(file, ptr, SEEK_SET) && die(1, "Can't move to method definition");
        fread(&offset, sizeof(U32), 1, file) == 1 || die(1, "Can't read method definition");
        flag = callback(virtual2raw(file, offset, info), ptr, userparam, info, file);
        ptr += methoddefsize;
    }
}

/** Get the name of a method
  *
  * buffer should be 256 bytes long
  */
void getmethodname(char* buffer, U32 declaration, struct dotnet_fileinfo *info, FILE* file)
{
    U32 nameoffset = 0;

    fseek(file, declaration + 4 + 2 + 2, SEEK_SET) && die(1, "Can't move to name offset");
    fread(&nameoffset, info->stridx, 1, file) == 1 || die(1, "Can't read name offset");

    fseek(file, nameoffset + getstream("#Strings", info, file), SEEK_SET) && die(1, "Can't move to name");
    fread(buffer, sizeof(char), 256, file) != 0 /* may be shorter, but not 0 */ || die(1, "Can't read name");
    buffer[255] = 0;    /* _always_ terminate strings! */
}

/** Decodes compressed integer pointed to by data
 *  data points to the byte following the integer on return
 *  Returns the integer
 *  Call like this: decodeinteger(&data);
 */

/*  Adapted from: Utilities.cs, part of the Cecil project
 *  Original author: Jb Evain (jbevain@gmail.com)
 *  Original copyright:
 *  Permission is hereby granted, free of charge, to any person obtaining
 *  a copy of this software and associated documentation files (the
 *  "Software"), to deal in the Software without restriction, including
 *  without limitation the rights to use, copy, modify, merge, publish,
 *  distribute, sublicense, and/or sell copies of the Software, and to
 *  permit persons to whom the Software is furnished to do so, subject to
 *  the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

uint decodeinteger(U8 **data_ptr)
{
    U8* data = *data_ptr;

    uint integer = 0;

    if((data[0] & 0x80) == 0)
    {
        integer = data[0];
        (*data_ptr)++;
    }
    else if((data[0] & 0x40) == 0)
    {
        integer =  (data[0] & ~0x80) << 8;
        integer |= data[1];
        (*data_ptr) += 2;
    }
    else
    {
        integer =  (data[0] & ~0xc0) << 24;
        integer |= data[1] << 16;
        integer |= data[2] << 8;
        integer |= data[3];
        (*data_ptr) += 4;
    }
    return integer;
}

/** Stores encoded (compressed) integer at the place pointed to by data
 *  Integer must be < 0x40000000
 *  data_ptr points to the byte following the integer on return
 *  Call like this: encodeinteger(&data, 0);
 */

/*  Again adapted, see notice at decodeinteger */

void encodeinteger(U8 **data_ptr, U32 integer)
{
    U8* data = *data_ptr;
    if (integer < 0x80)
    {
        data[0] = integer;
        (*data_ptr)++;
    }
    else if (integer < 0x4000)
    {
        data[0] = (integer >> 8) | 0x80;
        data[1] = (integer & 0xff);
        (*data_ptr) += 2;
    }
    else
    {
        data[0] = (integer >> 24) | 0xc0;
        data[1] = (integer >> 16) & 0xff;
        data[2] = (integer >>  8) & 0xff;
        data[3] = integer & 0xff;
        (*data_ptr) += 4;
    }
}

/** General purpose Intermediate Language bytecode length disassembly engine */
/* Caveat emptor: treats the (rare) prefixes as instructions */
uint il_lde(const U8 *opcodes) __attribute__((pure));
uint il_lde(const U8 *opcodes)
{
    /* Main length table for each IL opcode */
    static const U8 lde[] =
    {
    /* 1  2  3  4  5  6  7  8  9  A  B  C  D  E  F  */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, /* 0x */
    2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, /* 1x */
    5, 9, 5, 9, 0, 1, 1, 5, 5, 5, 1, 2, 2, 2, 2, 2, /* 2x */
    2, 2, 2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, /* 3x */
    5, 5, 5, 5, 5, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 4x */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 5x */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, /* 6x */
    5, 5, 5, 5, 5, 5, 1, 0, 0, 5, 1, 5, 5, 5, 5, 5, /* 7x */
    5, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 5, 1, 5, /* 8x */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 9x */
    1, 1, 1, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* Ax */
    0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, /* Bx */
    0, 0, 5, 1, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* Cx */
    5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 2, 1, /* Dx */
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* Ex */
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0  /* Fx */
    };

    /* Length table for extended IL opcodes */
    static const U8 lde2[] =
    {
    /* 1  2  3  4  5  6  7  8  9  A  B  C  D  E  F  */
    2, 2, 2, 2, 2, 2, 6, 6, 0, 4, 4, 4, 4, 4, 4, 2, /* 0x  */
    0, 2, 3, 2, 2, 6, 6, 2, 2, 0, 2, 0, 2, 2, 2, 0  /* 1x  */
    };

    if(opcodes[0] == 0x45)           /* special case for switch */
        return (*(U32 *)(opcodes+1)) * 4 + 5;

    else if(opcodes[0] == 0xFE) /* extended opcodes */
    {
        if(opcodes[1] <= 0x1F)
            return lde2[opcodes[1]];
        else
            return 0;
    }
    else
        return lde[opcodes[0]];
}

/** Does execution continue to next instruction? */
int continues(const U8 *opcodes) __attribute__((pure));
int continues(const U8 *opcodes)
{
    /* Main continuation table for each IL opcode */
    static const U8 continue_table[] =
    {
    /* 1  2  3  4  5  6  7  8  9  A  B  C  D  E  F */
    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 0x - NOP is special */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 1x */
    1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, /* 2x */
    1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, /* 3x */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 4x */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 5x */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 6x */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, /* 7x */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 8x */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 9x */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* Ax */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* Bx */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* Cx */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, /* Dx */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* Ex */
    1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0  /* Fx */
    };

    /* Continuation table for extended IL opcodes */
    static const U8 continue_table2[] =
    {
    /* 1  2  3  4  5  6  7  8  9  A  B  C  D  E  F  */
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, /* 0x */
    1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0  /* 1x */
    };

    if(opcodes[0] == 0xFE)
    {
        if(opcodes[1] <= 0x1F)
            return continue_table2[opcodes[1]];
        else
            return 0;
    }
    else
        return continue_table[opcodes[0]];
}

/** Get branch type */
enum branchtypes getbranchtype(const U8 *here) __attribute__((pure));
enum branchtypes getbranchtype(const U8 *here)
{
    U8 opcode;

    opcode = *here;
    if(opcode >= 0x38 && opcode <= 0x44 )
        opcode -= 0x0D;     /* Convert long branches to short, for simplicity */

    switch(opcode)
    {
    case 0x00:  /* treat NOPs as branch to next non-nop */
    case 0x2B:
        return BR_UNCONDITIONAL;

    case 0x2C:
        return BR_FALSE;

    case 0x2D:
        return BR_TRUE;

    case 0x2E:
        return BR_EQUAL;

    case 0x2F:
        return BR_GREATER_EQUAL;

    case 0x30:
        return BR_GREATER;

    case 0x31:
        return BR_LESS_EQUAL;

    case 0x32:
        return BR_LESS;

    case 0x33:
        return BR_UN_NEQUAL;

    case 0x34:
        return BR_UN_GREATER_EQUAL;

    case 0x35:
        return BR_UN_GREATER;

    case 0x36:
        return BR_UN_LESS_EQUAL;

    case 0x37:
        return BR_UN_LESS;

    case 0x45:
        return BR_SWITCH;

    case 0xDD:
    case 0xDE:
        return BR_LEAVE;

    default:
        return BR_NOTBRANCH;
    }
}

/** Get name of branch type as string */
void getbranchtypename(enum branchtypes type, char *buffer)
{
    switch(type)
    {
        case BR_NOTBRANCH:
            strcpy(buffer, "BR_NOTBRANCH");
            break;

        case BR_UNCONDITIONAL:
            strcpy(buffer, "BR_UNCONDITIONAL");
            break;

        case BR_FALSE:
            strcpy(buffer, "BR_FALSE");
            break;

        case BR_TRUE:
            strcpy(buffer, "BR_TRUE");
            break;

        case BR_EQUAL:
            strcpy(buffer, "BR_EQUAL");
            break;

        case BR_GREATER_EQUAL:
            strcpy(buffer, "BR_GREATER_EQUAL");
            break;

        case BR_GREATER:
            strcpy(buffer, "BR_GREATER");
            break;

        case BR_LESS_EQUAL:
            strcpy(buffer, "BR_LESS_EQUAL");
            break;

        case BR_LESS:
            strcpy(buffer, "BR_LESS");
            break;

        case BR_UN_NEQUAL:
            strcpy(buffer, "BR_UN_NEQUAL");
            break;

        case BR_UN_GREATER_EQUAL:
            strcpy(buffer, "BR_UN_GREATER_EQUAL");
            break;

        case BR_UN_GREATER:
            strcpy(buffer, "BR_UN_GREATER");
            break;

        case BR_UN_LESS_EQUAL:
            strcpy(buffer, "BR_UN_LESS_EQUAL");
            break;

        case BR_UN_LESS:
            strcpy(buffer, "BR_UN_LESS");
            break;

        case BR_SWITCH:
            strcpy(buffer, "BR_SWITCH");
            break;

        case BR_LEAVE:
            strcpy(buffer, "BR_LEAVE");
            break;

        default:
            strcpy(buffer, "UNKNOWN?");
            break;
    }
}

/** Get targets of branch, including implicit "fallthrough" target */
void* getdirecttarget(const U8* here, uint targetnum)
{
    uint nopcounter;

    if(here[0] == 0x00) /* Jump over nops */
    {
        if(targetnum != 0)
            return NULL;

        nopcounter = 0;
        do
        {
            nopcounter++;
        } while(here[nopcounter] == 0x00);
        return (void *)(here+nopcounter);
    }

    if(continues(here)) /* implicit "fallthrough" target first */
    {
        if(targetnum == 0)
            return (void *)(here+il_lde(here));

        targetnum--;
    }

    if(*here == 0x45) /* switch */
    {
        if(targetnum < *(U32 *)(here + 1))
            return (void *)(here+il_lde(here)+*(S32 *)(here + 5 + targetnum * sizeof(S32)));
        else
            return NULL;
    }

    if(targetnum == 0)
    {
        if((*here >= 0x2B && *here <= 0x37) || *here == 0xDE) /* short branch/leave */
            return (void *)(here+2+*(S8 *)(here + 1));

        if((*here >= 0x38 && *here <= 0x44) || *here == 0xDD) /* long branch/leave */
            return (void *)(here+5+*(S32 *)(here + 1));
    }

    return NULL;
}

/** Get targets of branch, including implicit "fallthrough" target
 *
 *  Resolves branches to unconditional branches
 */
void* gettarget(const U8* here, uint targetnum) __attribute__((pure));
void* gettarget(const U8* here, uint targetnum)
{
    uint counter = 0;
    U8 *temp;

    temp = getdirecttarget(here, targetnum);

    while(temp != NULL && getbranchtype(temp) == BR_UNCONDITIONAL && counter < 1000)
    {
        temp = getdirecttarget(temp, 0);
        counter++;
    }

    if(counter >= 1000)
        return getdirecttarget(here, targetnum);    /* Infinite loop, f.i. br <-> br */

    return temp;
}

/** Make a new branch of type "type", with targets to the start of the branch + delta[0..n]
 *
 *  Returns the number of bytes required for the branch, and the branch itself if "buffer" was sufficient
 */
uint makebranch(enum branchtypes type, S32 *deltas, uint numdeltas, U8 *buffer /** can be NULL */, uint bufsize /** ignored if buffer is NULL */)
{
    uint length, i;

    if(type == BR_NOTBRANCH)
        return 0;

    assert(numdeltas >= 0);

    if(type == BR_UNCONDITIONAL && deltas[0] == 0)
    {
        assert(numdeltas == 1);
        return 0;
    }

/* SWITCH */
    if(type == BR_SWITCH)
    {
        length = 5 + ((numdeltas - 1) * sizeof(S32));
        if(buffer != NULL && length <= bufsize)
        {
            buffer[0] = 0x45;
            *(U32 *)(buffer + 1) = numdeltas - 1;
            for(i = 1; i < numdeltas; i++)
                *(S32 *)(buffer + 1 + i * sizeof(S32)) = deltas[i] - length;
        }
        deltas[0] -= length;
        return length + makebranch(BR_UNCONDITIONAL, deltas, 1, buffer != NULL ? buffer + length : NULL, bufsize - length);
    }

/* LEAVE */
    if(type == BR_LEAVE)
    {
        assert(numdeltas == 1);
        if(deltas[0] >= -126 && deltas[0] <= 129) /* Delta values adjusted for 2-byte instruction */
        {
            if(buffer != NULL && bufsize >= 2)
            {
                buffer[0] = 0xDE;
                *(S8 *)(buffer + 1) = deltas[0] - 2;
            }
            return 2;
        }

        if(buffer != NULL && bufsize >= 5)
        {
            buffer[0] = 0xDD;
            *(S32 *)(buffer + 1) = deltas[0] - 5;
        }
        return 5;
    }

/* ALL BRANCHES */
    else if(type != BR_UNCONDITIONAL)
    {
        assert(numdeltas == 2);
        deltas++; /* Now delta[0] is actually delta[1] */
    }

    if(deltas[0] >= -126 && deltas[0] <= 129)
    {
        if(buffer != NULL && bufsize >= 2)
        {
            buffer[0] = 0x2B + (type - BR_UNCONDITIONAL);
            *(S8 *)(buffer + 1) = deltas[0] - 2;
        }
        length = 2;
    }
    else
    {
        if(buffer != NULL && bufsize >= 5)
        {
            buffer[0] = 0x38 + (type - BR_UNCONDITIONAL);
            *(S32 *)(buffer + 1) = deltas[0] - 5;
        }
        length = 5;
    }

    if(type != BR_UNCONDITIONAL)
    {
        assert(numdeltas == 2);
        deltas--;
        deltas[0] -= length;
        return length + makebranch(BR_UNCONDITIONAL, deltas, 1, buffer != NULL ? buffer + length : NULL, bufsize - length);
    }

    return length;
}

