/* This file is part of .deobfuscate (also known as dotdeobfuscate).

   Copyright 2007, someone with a name that hashes to
   382d54883bde4178ba136eba1719fa57816cd971 using RIPEMD-160.

   .deobfuscate is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   .deobfuscate is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */


/** \file
 *  This file has some often used functions that aren't specific to XenoDecode
 */

#include <assert.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"

U32 debugflags = 0;

/** Printf an error message and then exit */
int die(unsigned char errorcode, const char* message, ...) __attribute__((noreturn)) __attribute__ ((format (printf, 2, 3)));
int die(unsigned char errorcode, const char* message, ...)
/* Could be void but then compilers complain about "(statement) || die(...)" */
{
    va_list argp;
    va_start(argp, message);
    vfprintf(stderr, message, argp);
    va_end(argp);
    exit(errorcode);
}

/** Printf a debug message, if the debug class is enabled */
void dbgprint(uint type, const char* message, ...)
{
    assert(type < 32);

    if((debugflags & (1 << type)) != 0)
    {
        va_list argp;
        va_start(argp, message);
        vfprintf(stdout, message, argp);
        va_end(argp);
        fflush(stdout);
    }
}

/** Toggle a debug class
 *  Returns the new status (1 = enabled, 0 = disabled)
 */
uint toggledebug(uint type)
{
    assert(type < 32);

    debugflags ^= 1 << type;
    return (debugflags >> type) & 1;
}

/** Returns the debugging status (1 = enabled, 0 = disabled)
 */
uint isdebug(uint type)
{
    assert(type < 32);

    return (debugflags >> type) & 1;
}

/** Malloc some memory, and die if it fails */
void* xmalloc(size_t size)
{
    void* temp;
    temp = malloc(size);
    dbgprint(MEM_DEBUG, "Malloc %d bytes at %08x {\n", size, temp);
    if(temp == NULL)
        die(1, "Memory allocation failure.");
    return temp;
}

/** Calloc some memory, and die if it fails */
void* xcalloc(size_t size)
{
    void* temp;
    temp = calloc(size, 1);
    dbgprint(MEM_DEBUG, "Calloc %d bytes at %08x {\n", size, temp);
    if(temp == NULL)
        die(1, "Memory callocation failure.");
    return temp;
}

/** Realloc some memory, and die if it fails */
void *xrealloc(void *ptr, size_t size)
{
    void* temp;

    if(ptr == NULL)
        return xmalloc(size);

    temp = realloc(ptr, size);
    dbgprint(MEM_DEBUG, "Realloc %d bytes from %08x to %08x\n", size, ptr, temp);
    if(temp == NULL)
    {
        die(1, "Memory reallocation failure");
    }
    return temp;
}

/** Free some memory */
void xfree(void *ptr)
{
    dbgprint(MEM_DEBUG, "Free at %08x }\n", ptr);
    free(ptr);
}
