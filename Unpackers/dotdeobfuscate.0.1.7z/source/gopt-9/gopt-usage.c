/*
 * THIS IS  gopt-usage.c
 * VERSION  9.0
 * BY       tom_v@users.sourceforge.net
 * SEE      http://gopt.sourceforge.net/
 *
 * I, Tom Vajzovic, am the author of this software and its documentation and
 * permanently disclaim all copyright and other intellectual property rights
 * in them, including the right to be identified as the author.
 *
 * I am fairly certain that this software does what the documentation says it
 * does, but I cannot guarantee that it does, or that it does what you think
 * it should, and I cannot guarantee that it will not have undesirable side
 * effects.
 *
 * You are free to use, modify and distribute this software as you please, but
 * you do so at your own risk.
 *
 *  Non-binding requests:
 *
 *  If you use or distribute this software:
 *
 *   - please let me know (just out of interest).
 *   - please leave these comments intact.
 *
 *  If you make money from this software:
 *   - please give me some if you can spare it.
 *
 *  If you modify this software:
 *   - please add your initials to the version number.
 *   - please let me see your changes.
 *   - please put you changes into the public domain.
 *   - please mark clearly what you have changed.
 *
 */

/** HEADERS **/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "gopt.h"

int main( int argc, const char **argv ){

  void *options= gopt_start(
    gopt_option( 'h', 0, gopt_shorts( 'h', '?' ), gopt_longs( "help", "HELP" ) ),
    gopt_option( 'z', 0, gopt_shorts( 0 ), gopt_longs( "version" ) ),
    gopt_option( 'v', GOPT_REPEAT, gopt_shorts( 'v' ), gopt_longs( "verbose" ) ),
    gopt_option( 'o', GOPT_ARG, gopt_shorts( 'o' ), gopt_longs( "output" ) )
  );

  /*
   * initialise four possible options to this program, some of which have aliases:
   *
   * -h -? --help --HELP
   * --version
   * -v --verbose  (which may be repeated for more verbosity)
   * -o --output  (which require an option argument)
   */

  FILE *out_stream;
  const char *filename;
  int verbosity;
  int i;

  options= gopt_sort( options, &argc, argv, stderr, exit, EXIT_FAILURE );
  /*
   * parse arguments.
   * on error, print to stderr and call exit(EXIT_FAILURE);
   */

  if( gopt_arg( options, 'o', &filename ) && strcmp( filename, "-" ) ){
    /*
     * if -o or --output was specified, and its argument was not "-"
     */

    out_stream= fopen( filename, "wb" );
    if( ! out_stream ){
      fprintf( stderr, "%s: %s: could not open file for output\n", argv[0], filename );
      exit( EXIT_FAILURE);
    }
  }
  else
    out_stream= stdout;

  if( gopt( options, 'h' ) ){
    /*
     * if any of the help options was specified
     */

    fprintf( out_stream, "help text\n" );
    exit( EXIT_SUCCESS );
  }
  if( gopt( options, 'z' ) ){
    /*
     * if --version was specified
     * NB: 'z' is just a key within the source code
     * if you specify -z, it will be treated as an unknown option
     */

    fprintf( out_stream, "version number\n" );
    exit( EXIT_SUCCESS );
  }
  verbosity= gopt( options, 'v' );
  /*
   * return value is the number of times that the option was specified
   */

  if( verbosity > 1 )
    fprintf( stderr, "being really verbose\n" );

  else if( verbosity )
    fprintf( stderr, "being verbose\n" );

  gopt_free( options );
  /*
   * release memory used
   * you can no longer call gopt() etc.
   */

  for( i= 0; i < argc; ++i )
    fprintf( out_stream, "%s\n", argv[i] );
    /*
     * all the options have been removed
     * leaving only the program name and operands
     */

  exit( EXIT_SUCCESS );
}
