/*
 * THIS IS  gopt.c
 * VERSION  9.0
 * BY       tom_v@users.sourceforge.net
 * SEE      http://gopt.sourceforge.net/
 *
 * I, Tom Vajzovic, am the author of this software and its documentation and
 * permanently disclaim all copyright and other intellectual property rights
 * in them, including the right to be identified as the author.
 *
 * I am fairly certain that this software does what the documentation says it
 * does, but I cannot guarantee that it does, or that it does what you think
 * it should, and I cannot guarantee that it will not have undesirable side
 * effects.
 *
 * You are free to use, modify and distribute this software as you please, but
 * you do so at your own risk.
 *
 *  Non-binding requests:
 *
 *  If you use or distribute this software:
 *
 *   - please let me know (just out of interest).
 *   - please leave these comments intact.
 *
 *  If you make money from this software:
 *   - please give me some if you can spare it.
 *
 *  If you modify this software:
 *   - please add your initials to the version number.
 *   - please let me see your changes.
 *   - please put you changes into the public domain.
 *   - please mark clearly what you have changed.
 *
 */

/** HEADERS **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gopt.h"


/** CONSTANTS **/


/** TYPES **/

typedef struct {

  int key;
  int flags;
  const char *shorts;
  const char **longs;

} opt_spec;

typedef struct {

  int key;
  const char *arg;

} opt;


/** MACROS **/

#ifdef DEBUG
#define DEBUGM( string, ... )   fprintf( stderr, string "\n", ## __VA_ARGS__ )
#else
#define DEBUGM(...)
#endif

#define DEBUG_HERE              DEBUGM( "%s:%d", __FILE__, __LINE__ );

/* calls strchr twice but is only used in case of error so I won't make it a function */
#define STRLEN_TO_EQ( str )     ( strchr( (str), '=' ) ? strchr( (str), '=' ) - (str) : strlen(str) )


/** LOCAL FUNCTION DECLARATIONS */

static int
add_short_opt(
    const opt_spec *opt_specs,
    opt *opts,
    char short_opt,
    const char *opt_arg
);

static int
add_long_opt(
    const opt_spec *opt_specs,
    opt *opts,
    const char *long_opt
);


/** EXPORTED FUNCTION DEFINITIONS */

void *
gopt_sort(
    void *vptr_opt_specs,
    int *main_argc,
    const char **main_argv,
    FILE *err_stream,
    void (*exit_fn)(int),
    int exit_status

){
#define FUNCTION_NAME "gopt_sort"
  int i;
  opt_spec *opt_specs;
  size_t n_opt_specs;
  size_t sowa_count;
  char *sowa= NULL;
  size_t opt_count;
  opt* opts= NULL;
  unsigned char expecting_opt_arg;
  unsigned char double_dashed;
  unsigned int next_operand_num;
  /*                                                                                                    LOCAL MACROS */

#define ERROR( message, ... ) {                                               \
  DEBUGM( "ERROR at %s:%d", __FILE__, __LINE__ );                             \
                                                                              \
  free( sowa );                                                               \
  free( opts );                                                               \
                                                                              \
  if( err_stream )                                                            \
    fprintf( err_stream, "%s: " message "\n", main_argv[0], ## __VA_ARGS__ ); \
                                                                              \
  if( exit_fn )                                                               \
    exit_fn( exit_status );                                                   \
                                                                              \
  return NULL;                                                                \
}

#define ADD_OPERAND() {                                                       \
  main_argv[ next_operand_num ]= main_argv[ i ];                              \
  ++next_operand_num;                                                         \
}

#define ADD_SHORT_OPT_ERR( short_opt, arg ) {                                 \
  switch( add_short_opt( opt_specs, opts, (short_opt), (arg) ) ){             \
    case 1:                                                                   \
      ERROR( "-%c: unknown option", (short_opt) );                            \
    case 2:                                                                   \
      ERROR( "-%c: option requires an option argument", (short_opt) );        \
    case 3:                                                                   \
      ERROR( "-%c: option may not be repeated", (short_opt) );                \
  }                                                                           \
}

#define ADD_LONG_OPT_ERR( long_opt ) {                                                                                    \
  switch( add_long_opt( opt_specs, opts, (long_opt) ) ){                                                                  \
    case 1:                                                                                                               \
      ERROR( "--%.*s: unknown option", (int)STRLEN_TO_EQ(long_opt), (long_opt) );                                         \
    case 2:                                                                                                               \
      ERROR( "--%.*s: option requires an option argument", (int)STRLEN_TO_EQ(long_opt), (long_opt) );                     \
    case 3:                                                                                                               \
      ERROR( "--%.*s: option may not be repeated (in any long or short form)", (int)STRLEN_TO_EQ(long_opt), (long_opt) ); \
    case 4:                                                                                                               \
      ERROR( "--%.*s: abbreviated option is ambiguous", (int)STRLEN_TO_EQ(long_opt), (long_opt) );                        \
  }                                                                                                                       \
}

  /*                                                                                               TEST PARAMETERS */
  if( ! vptr_opt_specs || ! main_argc || 0 > *main_argc  || ! main_argv ){
    ERROR( "invalid argument to function %s()\nThis is a bug in the calling program, not in libgopt.", FUNCTION_NAME );
  }
  for( i= 0; i < *main_argc; ++i )
    if( ! main_argv[ i ] ){
      ERROR( "invalid argument to function %s()\nThis is a bug in the calling program, not in libgopt.", FUNCTION_NAME );
    }
  if( 2 > *main_argc ){
    opts= (opt*) malloc( sizeof( opt ) );
    if( ! opts ){
      ERROR( "unable to allocate memory" );
    }
    opts-> key= 0;
    return (void*) opts;
  }
                                                                                    /* FIND SHORT OPTIONS WITH ARGS */
  opt_specs= (opt_spec*) vptr_opt_specs;
  n_opt_specs= 0;
  sowa_count= 0;

  for( ; opt_specs[ n_opt_specs ]. key; ++n_opt_specs )
    if( GOPT_ARG & opt_specs[ n_opt_specs ]. flags )
      sowa_count+= strlen( opt_specs[ n_opt_specs ]. shorts );

  /* NB: I do not check for duplicated keys, shorts and longs */

  sowa= (char*) malloc( sowa_count + 1 );
  if( ! sowa ){
    ERROR( "unable to allocate memory" );
  }
  *sowa= 0; /* blank string */

  for( i= 0; i < n_opt_specs; ++i )
    if( GOPT_ARG & opt_specs[ i ]. flags )
      strcat( sowa, opt_specs[ i ]. shorts );
                                                                                                 /* COUNT OPTIONS */
  opt_count= 0;

  for( i= 1; i < *main_argc; ++i )
    if( '-' == main_argv[i][0] && main_argv[i][1] ){
      if( '-' == main_argv[i][1] )
        if( main_argv[i][2] )
          ++ opt_count;
        else
          break;
      else
        if( strchr( sowa, main_argv[i][1] ) )
          ++ opt_count;
        else
          opt_count+= strlen( main_argv[i] + 1 );
    }

  opts= (opt*) calloc( opt_count + 1, sizeof( opt ) );
  if( ! opts ){
    ERROR( "unable to allocate memory" );
  }                                                                                               /* READ OPTIONS */
  expecting_opt_arg= 0;
  double_dashed= 0;
  next_operand_num= 1;

  for( i= 1; i < *main_argc; ++i ){
#define next (main_argv[i])

    if( double_dashed ){
      ADD_OPERAND();
    }
    else if( ! next[0] || ! next[1] || '-' != next[0] ){

      if( ! expecting_opt_arg ){
        ADD_OPERAND();
      }
      expecting_opt_arg= 0;
    }
    else {      /* we have at least one dash */

      if( expecting_opt_arg ){
        ERROR( "-%c: option requires an option argument", main_argv[ i - 1 ][ 1 ] );
      }
      if( '-' == next[1] ){  /* we have at least two dashes */

        if( next[2] ){
          ADD_LONG_OPT_ERR( main_argv[ i ] + 2 );
        }
        else
          double_dashed= 1;
      }
      else {    /* we have only one dash */

        if( next[2] ){        /* we have one dash and at least two more chars */

          if( strchr( sowa, next[1] ) ){           /* we have one short option and its argument */
            ADD_SHORT_OPT_ERR( main_argv[i][1], main_argv[ i ] + 2 );
          }
          else {       /* we have multi short options */

            const char *opt= next + 1;
            for( ; *opt; ++opt ){
              if( strchr( sowa, *opt ) ){
                ERROR( "-%c: options which take option arguments may not be grouped", *opt );
              }
              ADD_SHORT_OPT_ERR( *opt, NULL );
            }
          }
        }
        else {     /* we have one dash and one more char */

          if( strchr( sowa, next[1] ) ){            /* we have a short option whose argument will follow */
            expecting_opt_arg= 1;
            ADD_SHORT_OPT_ERR( next[1], main_argv[ i + 1 ] );
          }
          else {           /* we have a short option with no argument */
            ADD_SHORT_OPT_ERR( next[1], NULL );
          }
        }
      }
    }
#undef next
  }
  if( expecting_opt_arg ){
    ERROR( "-%c: option requires an option argument", main_argv[ i - 1 ][ 1 ] );
  }
  main_argv[ next_operand_num ]= NULL;
  *main_argc= next_operand_num;

  free( sowa );

  return (void*) opts;

#undef ERROR
#undef ADD_OPERAND
#undef ADD_SHORT_OPT_ERR
#undef ADD_LONG_OPT_ERR

#undef FUNCTION_NAME
}

/*                                                                                                            GOPT */
int
gopt(
    void *vptr_opts,
    int key
){
  int count= 0;
  const opt *opts= (const opt*) vptr_opts;

  for( ; opts-> key; ++opts )
    if( opts-> key == key )
      ++count;

  return count;
}

/*                                                                                                        GOPT_ARG */
int
gopt_arg(
    void *vptr_opts,
    int key,
    const char **opt_arg
){
  int count= 0;
  const opt *opts= (const opt*) vptr_opts;

  for( ; opts-> key; ++opts )
    if( opts-> key == key ){
      *opt_arg= opts-> arg;
      ++count;
    }
  return count;
}

/*                                                                                                       GOPT_ARGS */
int
gopt_args(
    void *vptr_opts,
    int key,
    int max_argc,
    int *opt_argc,
    const char **opt_argv
){
  int count= 0;
  const opt *opts= (const opt*) vptr_opts;

  for( *opt_argc= 0; opts-> key; ++opts )
    if( opts-> key == key ){
      if( *opt_argc < max_argc ){
        opt_argv[ *opt_argc ]= opts-> arg;
        ++*opt_argc;
      }
      ++count;
    }
  opt_argv[ *opt_argc ]= NULL;

  return count;
}

/*                                                                                                         GOPT_FREE */
void
gopt_free(
    void *vptr_opts
){
  free( vptr_opts );
}


/** LOCAL FUNCTION DEFINITIONS */

static int
add_short_opt(
    const opt_spec *opt_specs,
    opt *opts,
    char short_opt,
    const char *opt_arg
){
  unsigned char found;

  for( found= 0; opt_specs-> key; ++opt_specs )
    if( strchr( opt_specs-> shorts, short_opt ) ){
      found= 1;
      break;
    }
  if( ! found )
    return 1;

  if( ( opt_specs-> flags & GOPT_ARG ) && ! opt_arg )
    return 2;

  if( ! ( opt_specs-> flags & GOPT_REPEAT ) ){
    for( ; opts-> key; ++opts )
      if( opts-> key == opt_specs-> key )
        return 3;
  }
  else
    for( ; opts-> key; ++opts );

  opts-> key= opt_specs-> key;
  opts-> arg= opt_arg;

  return 0;
}

static int
add_long_opt(
    const opt_spec *opt_specs,
    opt *opts,
    const char *long_opt
){
  int prev= -1;
  int i, j;
  size_t len;
  const char *eq= strchr( long_opt, '=' );

  if( eq )
    len= eq - long_opt;

  else
    len= strlen( long_opt );

  for( i= 0; opt_specs[ i ]. key; ++i )
    for( j= 0; opt_specs[ i ]. longs[ j ]; ++j )
      if( ! strncmp( opt_specs[ i ]. longs[ j ], long_opt, len ) ){
        if( -1 != prev )
          return 4;

        prev= i;
      }

  if( -1 == prev )
    return 1;

  opt_specs+= prev;

  if( ( opt_specs-> flags & GOPT_ARG ) && ! eq )
    return 2;

  if( ! ( opt_specs-> flags & GOPT_REPEAT ) ){
    for( ; opts-> key; ++opts )
      if( opts-> key == opt_specs-> key )
        return 3;
  }
  else
    for( ; opts-> key; ++opts );

  opts-> key= opt_specs-> key;

  if( eq )
    opts-> arg= eq + 1;

  else
    opts-> arg= NULL;

  return 0;
}
