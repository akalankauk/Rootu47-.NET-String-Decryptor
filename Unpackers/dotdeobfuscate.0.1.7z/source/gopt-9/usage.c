/* gopt-usage.c PUBLIC DOMAIN */

/** HEADERS **/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "gopt.h"

int main( int argc, const char **argv ){

  void *options= gopt_start(
    gopt_option( 'h', 0, gopt_shorts( 'h', '?' ), gopt_longs( "help", "HELP" ) ),
    gopt_option( 'z', 0, gopt_shorts( 0 ), gopt_longs( "version" ) ),
    gopt_option( 'v', GOPT_REPEAT, gopt_shorts( 'v' ), gopt_longs( "verbose" ) ),
    gopt_option( 'o', GOPT_ARG, gopt_shorts( 'o' ), gopt_longs( "output" ) )
  );
  const char *filename;
  int verbosity;
  int i;
  
  options= gopt_sort( options, &argc, argv, stderr, exit, EXIT_SUCCESS );

  if( gopt_arg( options, 'o', &filename ) && strcmp( filename, "-" ) ){

    fclose( stdout );
    stdout= fopen( filename, "wb" );

    if( ! stdout ){
      fprintf( stderr, "%s: %s: could not open file for output\n", argv[0], filename );
      exit( EXIT_FAILURE);
    }
  }
  if( gopt( options, 'h' ) ){
    fprintf( stdout, "help text\n" );
    exit( EXIT_SUCCESS );
  }
  if( gopt( options, 'z' ) ){
    fprintf( stdout, "version number\n" );
    exit( EXIT_SUCCESS );
  }
  verbosity= gopt( options, 'v' );

  if( verbosity > 1 ) 
    fprintf( stderr, "being really verbose\n" );

  else if( verbosity )
    fprintf( stderr, "being verbose\n" );
  
  gopt_free( options );

  for( i= 0; i < argc; ++i )
    fprintf( stdout, "%s\n", argv[i] );

  exit( EXIT_SUCCESS );
}
