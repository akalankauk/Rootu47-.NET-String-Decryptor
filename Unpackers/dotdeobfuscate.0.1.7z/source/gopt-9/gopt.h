/*
 * THIS IS  gopt.h
 * VERSION  9.0
 * BY       tom_v@users.sourceforge.net
 * SEE      http://gopt.sourceforge.net/
 *
 * I, Tom Vajzovic, am the author of this software and its documentation and
 * permanently disclaim all copyright and other intellectual property rights
 * in them, including the right to be identified as the author.
 *
 * I am fairly certain that this software does what the documentation says it
 * does, but I cannot guarantee that it does, or that it does what you think
 * it should, and I cannot guarantee that it will not have undesirable side
 * effects.
 *
 * You are free to use, modify and distribute this software as you please, but
 * you do so at your own risk.
 *
 *  Non-binding requests:
 *
 *  If you use or distribute this software:
 *
 *   - please let me know (just out of interest).
 *   - please leave these comments intact.
 *
 *  If you make money from this software:
 *   - please give me some if you can spare it.
 *
 *  If you modify this software:
 *   - please add your initials to the version number.
 *   - please let me see your changes.
 *   - please put you changes into the public domain.
 *   - please mark clearly what you have changed.
 *
 */

#ifndef _GOPT_H
#define _GOPT_H


/** HEADERS **/

#include <stdio.h>


/** CONSTANTS **/

#define GOPT_ONCE    0
#define GOPT_REPEAT  1

#define GOPT_NOARG  0
#define GOPT_ARG    2


/** MACROS **/

#if 0 == 0 /* avoid syntax highlighting problems in gvim */

#define gopt_start(...)                           (void*)( const struct { int k; int f; const char *s; const char **l; } [] ) \
                                                  { __VA_ARGS__, { 0, 0, "", (const char**)(const char*[]){ NULL } } }
#define gopt_option( key, flags, shorts, longs )  { key, flags, shorts, longs }
#define gopt_shorts( ... )                        (const char*)(const char[]){ __VA_ARGS__, '\0' }
#define gopt_longs( ... )                         (const char**)(const char*[]){ __VA_ARGS__, NULL }

#endif

/** FUNCTIONS **/

void *
gopt_sort(
    void *vptr_opt_specs,
    int *main_argc,
    const char **main_argv,
    FILE *err_stream,
    void (*exit_fn)(int),
    int exit_status
);

int
gopt(
    void *vptr_opts,
    int key
);

int
gopt_arg(
    void *vptr_opts,
    int key,
    const char **opt_arg_ptr
);

int
gopt_args(
    void *vptr_opts,
    int key,
    int max_opt_args,
    int *opt_argc_ptr,
    const char **opt_argv
);

void
gopt_free(
    void *vptr_opts
);

#endif /* _GOPT_H */

