/* This file is part of .deobfuscate (also known as dotdeobfuscate).

   Copyright 2007, someone with a name that hashes to
   382d54883bde4178ba136eba1719fa57816cd971 using RIPEMD-160.

   .deobfuscate is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   .deobfuscate is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */


/** \file
 *  Anti-protector functions can go here.
 *  I don't target any specific protectors, both because it is senseless
 *  (they change 1 byte and you can start over again) and due to legal reasons.
 */

#include <stdio.h>
#include <string.h>

#include "defines.h"
#include "dotnet.h"
#include "includes.h"

/** Remove simple obscufations */
void removeobfuscation(U8 *here, void* userparam)
{
    S32 value, delta;
    U8 *jump;
    uint firstsize, fullsize;

/* if(0x1234 != 0) -> goto */
    if(here[0] == 0x20 || here[0] == 0x16 || here[0] == 0x17)     /* ldc.i4 ??? / ldc.i4.0  / ldc.i4.1 */
    {
        firstsize = il_lde(here);
        jump = here + firstsize;

        if(getbranchtype(jump) == BR_TRUE || getbranchtype(jump) == BR_FALSE)
        /* brfalse/brtrue ??? */
        {
            value = here[0] == 0x20 ? *(S32 *)(here+1) : (here[0] == 0x16 ? 0 : 1);
            fullsize = firstsize + il_lde(jump);
            if((value != 0) == (getbranchtype(jump) == BR_TRUE)) /* branch taken? */
            {
                /* Make unconditional branch */
                delta = (uint)getdirecttarget(jump, 1) - (uint)jump; /* Need direct else jump may go out of reach! */

                memset(here, 0x00, fullsize);  /* NOP it */
                makebranch(BR_UNCONDITIONAL, &delta, 1, jump, fullsize + here - jump);
            }
            else
            {
                memset(here, 0x00, fullsize);  /* NOP it */
            }
        }
    }
}
