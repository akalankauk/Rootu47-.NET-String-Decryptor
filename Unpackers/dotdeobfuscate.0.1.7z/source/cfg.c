/* This file is part of .deobfuscate (also known as dotdeobfuscate).

   Copyright 2007, someone with a name that hashes to
   382d54883bde4178ba136eba1719fa57816cd971 using RIPEMD-160.

   .deobfuscate is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   .deobfuscate is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */


/** \file
 *  This is the file that handles method control flow graphs.
 *  Methods are broken up into basic blocks and simultaniously a bit deobfuscated
 *  Then they are reordered and rebuilded.
 *
 *  When this is done, you have a nice clean function instead of a spider web.
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "defines.h"
#include "dotnet.h"
#include "includes.h"

/** A vertex in the control flow graph. */
struct vertexstruct
{
    /** Start address of the vertex. */
    void *start;
    /** End address of the vertex, not including the final branch. */
    void *end;
    /** End address of the vertex, including the final branch. */
    void *realend;
    /** The number of exit adresses.
     *  For conditional branches, this includes the adress after the branch ("fallthrough").
     */
    uint numexits;
    /** The type of the exits. */
    enum branchtypes exittype;
    /** Pointer to an array of exit adresses. */
    uint *exits;
};

/** The root of the control flow graph. */
struct cfgstruct
{
    /** Start of the memory area that may be used in this method. */
    void *start;
    /** Size of the memory area that may be used in this method. */
    uint size;
    /** The number of vertices in this cfg. */
    uint numvertices;
    /** A pointer to an array of the vertices. */
    struct vertexstruct *vertices;
};

/** Check if an address is in the contol flow graph somewhere.
 *  Returns the vertex number in which it is found
 *  or -1 if it isn't found.
 */
int findincfg(void* ptr, struct cfgstruct *cfg) __attribute__((pure));
int findincfg(void* ptr, struct cfgstruct *cfg)
{
    uint i;

    for(i = cfg->numvertices - 1; i != -1; i--)    /* Searching backwards is good for performance, not 100% sure why */
        if(cfg->vertices[i].start <= ptr && cfg->vertices[i].realend > ptr)
        {
            if(cfg->vertices[i].end >= ptr)
                return i;
            else
                return -1; /* Branch into middle of another branch? Wtf? */
        }

    return -1;
}

/** Check if an address is the start of a vertex.
 *  Returns the vertex that has this start or -1 if it isn't found.
 */
uint findvertex(void* start, struct cfgstruct *cfg) __attribute__((pure));
uint findvertex(void* start, struct cfgstruct *cfg)
{
    uint i;

    for(i = cfg->numvertices - 1; i != -1; i--)    /* Searching backwards is good for performance, not 100% sure why */
        if(cfg->vertices[i].start == start)
            return i;

    return -1;
}

/** Make a contol flow graph for a function by making basic blocks and following branches.
 *  This is a recursive function.
 */
void makecfg(U8 *here, struct cfgstruct *cfg, void (*removeobfuscation)(U8*, void*), void* userparam)
{
    uint thisvertex, i, thisexit, found, ournumexits, *ourexits;
    void* target, **ourtargets;

    found = findincfg(here, cfg);

    thisvertex = cfg->numvertices; /* This vertex is a new one at the end of the array */
    cfg->numvertices++;

/* Init some stuff */
    cfg->vertices = xrealloc(cfg->vertices, cfg->numvertices * sizeof(struct vertexstruct));
    cfg->vertices[thisvertex].start = here;
    cfg->vertices[thisvertex].numexits = 0;
    cfg->vertices[thisvertex].exittype = BR_NOTBRANCH;

    /* Check if this is the middle of another vertex */
    if(found != -1)
    {
        dbgprint(CFG_DEBUG, "Splitting vertex %d, into %d and %d\n", found, found, thisvertex);
        cfg->vertices[thisvertex].end      = cfg->vertices[found].end;
        cfg->vertices[thisvertex].realend  = cfg->vertices[found].realend;
        cfg->vertices[thisvertex].exittype = cfg->vertices[found].exittype;
        cfg->vertices[thisvertex].numexits = cfg->vertices[found].numexits;
        cfg->vertices[thisvertex].exits    = cfg->vertices[found].exits;

        cfg->vertices[found].end      = here;
        cfg->vertices[found].realend  = here;
        cfg->vertices[found].exittype = BR_UNCONDITIONAL;
        cfg->vertices[found].numexits = 1;
        cfg->vertices[found].exits    = xmalloc(1 * sizeof(uint));
        cfg->vertices[found].exits[0] = thisvertex;
        return;
    }

/* Main loop working on the IL */
    while(1)
    {
        cfg->vertices[thisvertex].end = here;      /* Grow vertex  */
        cfg->vertices[thisvertex].realend = here;  /* ditto        */

        if((found = findincfg(here, cfg)) != -1)  /* Overlapping with another vertex? */
        {
            /* Then stop */
            cfg->vertices[thisvertex].exittype = BR_UNCONDITIONAL;
            cfg->vertices[thisvertex].numexits = 1;
            cfg->vertices[thisvertex].exits    = xmalloc(1 * sizeof(uint));
            cfg->vertices[thisvertex].exits[0] = found;
            break;
        }

        removeobfuscation(here, userparam); /* Apply deobscufations, usually pattern replacing, on this instruction */

        if(getbranchtype(here) != BR_NOTBRANCH )    /* If this is a branch */
        {
            cfg->vertices[thisvertex].exittype = getbranchtype(here);
            cfg->vertices[thisvertex].realend = here + il_lde(here);
            ourtargets = NULL;

            for(i = 0; (target = gettarget(here, i)) != 0; i++) /* For every branch... */
            {
                if(target < cfg->start || target >= cfg->start + cfg->size)    /* Bounds check the target */
                {
                    fprintf(stderr, "L_%04x: Target L_%x outside of function!\n", (uint)here - (uint)cfg->start,(uint)target-(uint)cfg->start);
                    continue;
                }

                thisexit = cfg->vertices[thisvertex].numexits; /* add an exit */
                cfg->vertices[thisvertex].numexits++;
                ourtargets = xrealloc(ourtargets, cfg->vertices[thisvertex].numexits * sizeof(uint));
                ourtargets[thisexit] = target;
            }

            cfg->vertices[thisvertex].exits = xmalloc(cfg->vertices[thisvertex].numexits * sizeof(uint));

            ourexits = cfg->vertices[thisvertex].exits;         /* Need to create local copies in case a split steals them */
            ournumexits = cfg->vertices[thisvertex].numexits;

            for(i = 0; i < ournumexits; i++)
            {
                target = ourtargets[i];
                if(findvertex(target, cfg) == -1)
                {
                    ourexits[i] = cfg->numvertices;         /* Exit points to a new vertex */
                    makecfg(target, cfg, removeobfuscation, userparam);    /* recursive following */
                }
                else
                {
                    ourexits[i] = findvertex(target, cfg);  /* Exit points to the found vertex */
                }
            }

            xfree(ourtargets);
            break; /* and stop */
        }

        if(il_lde(here) == 0)
        {
            fprintf(stderr, "L_%04x: Unknown opcode %02x, %02x\n", (uint)here - (uint)cfg->start, here[0], here[1]);
            break;
        }

        if(!continues(here))    /* does the block end here? */
        {
            cfg->vertices[thisvertex].end = here + il_lde(here);
            cfg->vertices[thisvertex].realend = here + il_lde(here);
            break;
        }

        here = here + il_lde(here); /* next please */
    }
}

/** Dump the cfg to stdout.
 *  This in a debugging function.
 */
void dumpcfg(struct cfgstruct *cfg)
{
    uint i, j, thestart;
    char *name;

    if(isdebug(CFG_DEBUG)) /* Not really necessary, but gives a huge performance gain if debugging is disabled */
    {
        dbgprint(CFG_DEBUG, "\n%d vertices:\n", cfg->numvertices);
        name = xcalloc(100);
        for(i = 0; i < cfg->numvertices; i++)
        {
            thestart = (uint)cfg->start;
            getbranchtypename(cfg->vertices[i].exittype, name);

            dbgprint(CFG_DEBUG, "\nVertex %d\nStart: 0x%x\nEnd: 0x%x\nRealend: 0x%x\nNumexits: %d\nType = %s\n", i, (uint)cfg->vertices[i].start - thestart, (uint)cfg->vertices[i].end - thestart, (uint)cfg->vertices[i].realend - thestart, cfg->vertices[i].numexits, name);
            for(j = 0; j < cfg->vertices[i].numexits; j++)
                dbgprint(CFG_DEBUG, "Exit %d: %d\n", j, cfg->vertices[i].exits[j]);
        }
        xfree(name);
    }
}

/** Recursive ordering of the basic blocks.
 *  At the moment it's quite simplistic.
 */
uint getorder(uint *order, struct cfgstruct *cfg, uint vertexindex, uint orderindex, uint depth)
{
    uint i;

    assert(vertexindex < cfg->numvertices);
    assert(orderindex  <=  cfg->numvertices);

    dbgprint(CFG_DEBUG, "\n");
    for(i = 0; i < depth; i++)
        dbgprint(CFG_DEBUG, " ");

    dbgprint(CFG_DEBUG, "%d/%d, vertex %d (%d exits): ", orderindex, cfg->numvertices, vertexindex, cfg->vertices[vertexindex].numexits);

    for(i = 0; i < orderindex; i++)  /* If vertex index already in order list, bail out */
        if(order[i] == vertexindex)
        {
            dbgprint(CFG_DEBUG, "found at %d", i);
            return orderindex - 1;
        }

    assert(orderindex < cfg->numvertices);
    dbgprint(CFG_DEBUG, "saved {");
    order[orderindex] = vertexindex;
    for(i = 0; i < cfg->vertices[vertexindex].numexits; i++)
    {
        orderindex = getorder(order, cfg, cfg->vertices[vertexindex].exits[i], orderindex+1, depth + 1);
    }
    dbgprint(CFG_DEBUG, "}");
    return orderindex;
}

/** Code fragment for rebuildcfg */
void makedeltas(S32 *deltas, uint thisvertex, uint *adresses, uint end, struct cfgstruct *cfg, uint* inverseorder)
{
    uint j, block;
    for(j = 0; j < cfg->vertices[thisvertex].numexits; j++)
    {
        block = cfg->vertices[thisvertex].exits[j];
        deltas[j] = adresses[inverseorder[block]] - end;
    }
}

/** Rebuild a function from it's control flow graph, reordering the basic blocks.
 *  Warning: this needs the memory pointed to by the cfg.
 */
uint rebuildcfg(U8* outbuffer, uint outlength, struct cfgstruct *cfg)
{
    uint *order, *inverseorder, length, flag, *sizes, i, j, maxnum, *adresses, *ends;
    S32 *deltas;

    dumpcfg(cfg);

    order = xmalloc(cfg->numvertices * sizeof(uint));

    maxnum = getorder(order, cfg, 0, 0, 0) + 1;

/* Calculate the inverse of the order table */
    inverseorder = xmalloc(cfg->numvertices * sizeof(uint));
    for(i = 0; i < maxnum; i++)
        inverseorder[order[i]] = i;

/* Debug order */
    if(isdebug(CFG_DEBUG))
    {
        dbgprint(CFG_DEBUG, "\nOrder:        ");
        for(i = 0; i < cfg->numvertices; i++)
            dbgprint(CFG_DEBUG, " %d", order[i]);

        dbgprint(CFG_DEBUG, "\nInverse order:");
        for(i = 0; i < cfg->numvertices; i++)
            dbgprint(CFG_DEBUG, " %d", inverseorder[i]);
        dbgprint(CFG_DEBUG, "\n\n");
    }

    sizes = xcalloc(maxnum * sizeof(uint)); /* Initializes sizes of the jumps with 0 */
    adresses = xmalloc(maxnum * sizeof(uint));
    ends = xmalloc(maxnum * sizeof(uint));

    do
    {
        flag = 1;   /* If this stays 1, the loop is done */
        length = 0; /* The length of the rebuilded function */
        for(i = 0; i < maxnum; i++) /* Calculate it ^^ */
        {
            adresses[i] = length;   /* Start of block i */
            length += (uint)cfg->vertices[order[i]].end - (uint)cfg->vertices[order[i]].start; /* + blocklength */
            ends[i] = length;       /* End of block i */
            length += sizes[i]; /* + branchsize */
        }

        for(i = 0; i < maxnum; i++) /* for each block */
        {
            deltas = xmalloc(cfg->vertices[order[i]].numexits * sizeof(S32));
            makedeltas(deltas, order[i], adresses, ends[i], cfg, inverseorder);        /* make the deltas */
            if(makebranch(cfg->vertices[order[i]].exittype, deltas, cfg->vertices[order[i]].numexits, NULL, 0) > sizes[i])
            {
                /* If the jump doesn't fit in the given space */
                flag = 0; /* Keep looping */

                /* Increase its space */

                /* FIXME: optimization is IL specific: original: sizes[i]++; */
                /* Only valid branches are 0, 2, or 5 bytes long (except switch, which is 4*x + 5) */
                /* There can be combinations of two, so 1, 3, 6, and 8 are impossible */
                /* It's worth it because this makes the function about 3x faster */
                sizes[i]++;
                if(sizes[i] == 1 || sizes[i] == 3 || sizes[i] == 6 || sizes[i] == 8)
                    sizes[i]++;
            }
            xfree(deltas);
        }
    }while(flag == 0);
    /* Now we know how much space the branches take */

    if(isdebug(CFG_DEBUG))
    {
        length = 0;
        for(i = 0; i < maxnum; i++)
        {
            dbgprint(CFG_DEBUG, "L_%x: block %d\n", length, order[i]);
            length += (uint)cfg->vertices[order[i]].end - (uint)cfg->vertices[order[i]].start;
            dbgprint(CFG_DEBUG, "L_%x: %d byte branch(es) to {", length, sizes[i]);

            deltas = xmalloc(cfg->vertices[order[i]].numexits * sizeof(S32));
            makedeltas(deltas, order[i], adresses, ends[i], cfg, inverseorder);
            for(j = 0; j < cfg->vertices[order[i]].numexits; j++)
                dbgprint(CFG_DEBUG, " %c%x", deltas[j] < 0 ? '-' : '+', deltas[j] < 0 ? -deltas[j] : deltas[j]);
            dbgprint(CFG_DEBUG, " }\n");
            xfree(deltas);

            length += sizes[i];
        }
    }

    if(length > outlength)
    {
        dbgprint(CFG_DEBUG, "Method became bigger (length 0x%x > 0x%x)?\n", length, outlength); /* That shouldn't happen */
        return -1;
    }

    length = 0;
    for(i = 0; i < maxnum; i++)
    {
        /* Almost the same as above, but this copies the blocks in place */
        adresses[i] = length;
        memcpy(outbuffer + length, cfg->vertices[order[i]].start, (uint)cfg->vertices[order[i]].end - (uint)cfg->vertices[order[i]].start);
        length += (uint)cfg->vertices[order[i]].end - (uint)cfg->vertices[order[i]].start;
        ends[i] = length;
        length += sizes[i];
    }

    for(i = 0; i < maxnum; i++)
    {
        /* Again almost the same, but this really makes the branches */
        deltas = xmalloc(cfg->vertices[order[i]].numexits * sizeof(S32));
        makedeltas(deltas, order[i], adresses, ends[i], cfg, inverseorder);
        if(makebranch(cfg->vertices[order[i]].exittype, deltas, cfg->vertices[order[i]].numexits, outbuffer + ends[i], sizes[i]) > sizes[i])
        {
            die(1, "WTF? Branch doesn't fit?");
        }
        xfree(deltas);
    }
    
    xfree(sizes);
    xfree(adresses);
    xfree(ends);
    xfree(inverseorder);
    return length;
}

/** Remove a control flow graph and deallocate all it's vertices. */
void freecfg(struct cfgstruct *cfg)
{
    uint i;

    for(i = 0; i < cfg->numvertices; i++)
        if(cfg->vertices[i].numexits > 0)
            xfree(cfg->vertices[i].exits);

    xfree(cfg->vertices);
}
